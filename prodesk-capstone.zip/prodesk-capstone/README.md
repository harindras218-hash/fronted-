# ProDesk Capstone – Walking Skeleton (Track B: Fullstack)

Stack: React (Vite) + Node/Express + MongoDB (Mongoose) + bcryptjs + JWT

## Run in VS Code
Prerequisites: Node.js 18+, MongoDB running locally (or use a MongoDB Atlas URI in `server/.env`).

Open this folder in VS Code (`File > Open Folder`), then open **two terminals** (`Ctrl + ~`):

**Terminal 1 – server**
```bash
cd server
npm install
npm run dev
```

**Terminal 2 – client**
```bash
cd client
npm install
npm run dev
```

Open http://localhost:5173

## Endpoints
| Method | Route | Access |
|---|---|---|
| POST | /api/auth/register | public |
| POST | /api/auth/login | public |
| GET  | /api/auth/me | JWT required |

## What is covered
- P0: User schema (name, email, password) + bcryptjs salt/hash in a pre-save hook
- P1: register/login return a signed JWT; React forms POST and store the token in localStorage
- P2: `middleware/auth.js` verifies the JWT; client redirects to /login if token is missing/expired (route guard + 401 interceptor)
