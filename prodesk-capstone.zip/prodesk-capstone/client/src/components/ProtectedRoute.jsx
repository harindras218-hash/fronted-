import { Navigate } from "react-router-dom";
import { isTokenValid, clearSession } from "../auth";

export default function ProtectedRoute({ children }) {
  if (!isTokenValid()) {
    clearSession();
    return <Navigate to="/login" replace />;
  }
  return children;
}
