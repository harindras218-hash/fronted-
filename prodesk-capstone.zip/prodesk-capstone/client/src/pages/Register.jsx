import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { api } from "../api";
import { saveSession } from "../auth";

export default function Register() {
  const nav = useNavigate();
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const onChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const onSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const { token, user } = await api("/auth/register", { method: "POST", body: form });
      saveSession(token, user);
      nav("/dashboard");
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ maxWidth: 360, margin: "60px auto", fontFamily: "sans-serif" }}>
      <h2>Register</h2>
      <form onSubmit={onSubmit}>
        <input name="name" placeholder="Name" value={form.name} onChange={onChange} required style={{ display: "block", width: "100%", marginBottom: 10 }} />
        <input name="email" type="email" placeholder="Email" value={form.email} onChange={onChange} required style={{ display: "block", width: "100%", marginBottom: 10 }} />
        <input name="password" type="password" placeholder="Password (min 6)" value={form.password} onChange={onChange} required minLength={6} style={{ display: "block", width: "100%", marginBottom: 10 }} />
        {error && <p style={{ color: "crimson" }}>{error}</p>}
        <button disabled={loading}>{loading ? "Creating..." : "Create account"}</button>
      </form>
      <p>Already registered? <Link to="/login">Login</Link></p>
    </div>
  );
}
