import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../api";
import { clearSession, getUser } from "../auth";

export default function Dashboard() {
  const nav = useNavigate();
  const [user, setUser] = useState(getUser());

  // Hits a JWT-protected endpoint to prove the middleware works
  useEffect(() => {
    api("/auth/me").then((d) => setUser(d.user)).catch(() => {});
  }, []);

  const logout = () => {
    clearSession();
    nav("/login");
  };

  return (
    <div style={{ maxWidth: 480, margin: "60px auto", fontFamily: "sans-serif" }}>
      <h2>Dashboard</h2>
      <p>Welcome, <b>{user?.name}</b> ({user?.email})</p>
      <button onClick={logout}>Logout</button>
    </div>
  );
}
